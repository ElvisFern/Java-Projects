import javax.swing.JOptionPane;

public class Project01 {

	public static void main(String[] args) {
		//define input variables
		String firstName, lastName;
		int p1,p2,p3,p4,p5,p6,p7;
		int h1,h2;
		int t1,t2,t3,t4;
		int att;
		double avgProjects= 0.00d,avgTest=0.00d,classGrade=0.00d;
		String input;
		
		//prompt user for input data
		firstName = JOptionPane.showInputDialog(null,
				"Enter First Name",
				"First Name",
				JOptionPane.QUESTION_MESSAGE);
		
		lastName = JOptionPane.showInputDialog(null,
				"Enter First Name",
				"Lastt Name",
				JOptionPane.QUESTION_MESSAGE);
		// get project grades
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 50",
				"Grade (Project 1)",
				JOptionPane.QUESTION_MESSAGE);
		p1 = Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 100",
				"Grade (Project 2)",
				JOptionPane.QUESTION_MESSAGE);
		p2 =Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 100",
				"Grade (Project 3)",
				JOptionPane.QUESTION_MESSAGE);
		p3 =Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 200",
				"Grade (Project 4)",
				JOptionPane.QUESTION_MESSAGE);
		p4 =Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 200",
				"Grade (Project 5)",
				JOptionPane.QUESTION_MESSAGE);
		p5 =Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 200",
				"Grade (Project 6)",
				JOptionPane.QUESTION_MESSAGE);
		p6 =Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 200",
				"Grade (Project 7)",
				JOptionPane.QUESTION_MESSAGE);
		p7 =Integer.parseInt(input);
	//Get Homework Grades	
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 50",
				"Grade (Homework 1)",
				JOptionPane.QUESTION_MESSAGE);
		h1 =Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 50",
				"Grade (Homework 2)",
				JOptionPane.QUESTION_MESSAGE);
		h2 =Integer.parseInt(input);
		// Get test Grades
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 100",
				"Grade (Test 1)",
				JOptionPane.QUESTION_MESSAGE);
		t1 =Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 100",
				"Grade (Test 2)",
				JOptionPane.QUESTION_MESSAGE);
		t2 =Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 100",
				"Grade (Test 3)",
				JOptionPane.QUESTION_MESSAGE);
		t3 =Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 100",
				"Grade (Test 4)",
				JOptionPane.QUESTION_MESSAGE);
		t4 =Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Enter interger number <= 28",
				"Number of class sessions attended",
				JOptionPane.QUESTION_MESSAGE);
		att =Integer.parseInt(input);
		// Calculate output values
		double attendance1 = (att/28.0)*100;
		avgProjects = ((p1+p2+p3+p4+p5+p6+p7)/1050.00d) *100.00d;
		avgTest = (t1+t2+t3+t4)/4;
		classGrade = (((avgProjects+h1+h2)/2)*.40d)+(avgTest*.5)+(attendance1*.1);
		//output the information
		JOptionPane.showMessageDialog(null,
				"           CSC 229 Project 1  "             +"\n"+
				"________________________________"             +"\n"+
				"                  First Name ="+ firstName  +"\n"+
				"                   Last Name ="+ lastName   +"\n"+
				"________________________________"             +"\n"+
				"        Project Grades        "             +"\n"+
				"________________________________"             +"\n"+
				"          Project 1 (50) ---  "+p1          +"\n"+
				"          Project 2 (100) --- "+p2          +"\n"+
				"          Project 3 (100) --- "+p3          +"\n"+
				"          Project 4 (200) --- "+p4          +"\n"+
				"          Project 5 (200) --- "+p5          +"\n"+
				"          Project 6 (200) --- "+p6          +"\n"+
				"          Project 7 (200) --- "+p7          +"\n"+
				"________________________________"             +"\n"+
				"       Homework Grades        "             +"\n"+
				"________________________________"             +"\n"+
				"         Homework 1 (50) ---  "+h1          +"\n"+
				"         Homework 2 (50) ---  "+h2          +"\n"+
				"________________________________"             +"\n"+
				"         Test Grades          "             +"\n"+
				"________________________________"             +"\n"+
				"          Test 1    (100) --- "+t1          +"\n"+
				"          Test 2    (100) --- "+t2          +"\n"+
				"          Test 3    (100) --- "+t3          +"\n"+
				"          Test 4    (100) --- "+t4          +"\n"+
				"________________________________"             +"\n"+
				"          Attendance (28) ---"+att+"of 28"     +"\n"+
				"________________________________"             +"\n"+
				"   %Grade from Projects    -->"+avgProjects +"\n"+
				"   %Grade from Test  -->"+avgTest     +"\n"+
				"   %Grade from Attendance  -->"+attendance1             +"\n"+
				"======================================"     +"\n"+
				"Percentage for Class       -->"+classGrade  +"\n"+
				"======================================"     +"\n"
				,
				"Project 1- Seyed",
				JOptionPane.INFORMATION_MESSAGE
				);


	}

}
