import javax.swing.JOptionPane;

public class Project02 {

	public static void main(String[] args) {
		// Variables
		String inputString;
		int phoneType, servicePlan, entService;
		int numberofSevices=0;
		double phoneCost=0.00,planCost=0.00, entCost=0.00, discount=0.00; 
		String phoneLabel ="", planLabel="",entLabel="",discountLabel="";
		String firstName, lastName, address, cityName, twoLetterStateCode,zipCode;
		
		
		
		
		
		//Input Dialog
				firstName= JOptionPane.showInputDialog(null,
				"Please Enter Your First Name",
				"First Name",
				JOptionPane.QUESTION_MESSAGE);
				
				lastName= JOptionPane.showInputDialog(null,
						"Please Enter Your Last Name",
						"Last Name",
						JOptionPane.QUESTION_MESSAGE);
				address= JOptionPane.showInputDialog(null,
						"Please Enter Your Address",
						"Address",
						JOptionPane.QUESTION_MESSAGE);
				cityName= JOptionPane.showInputDialog(null,
						"Please Enter Your City",
						"City",
						 JOptionPane.QUESTION_MESSAGE);
				twoLetterStateCode= JOptionPane.showInputDialog(null, 
						"Please Enter Your State 2 letter code",
						"2 Letter Code",
						 JOptionPane.QUESTION_MESSAGE);
				zipCode = JOptionPane.showInputDialog(null,
						"Please Enter Your Zip Code",
						"Zip Code",
						 JOptionPane.QUESTION_MESSAGE);
		
				
				inputString = JOptionPane.showInputDialog(null,
				"          Please Select Your Smart Phone           " +"\n"+
				"          Price/Month for 24 Months                " +"\n"+
				"___________________________________________________" +"\n"+
				"1. Samsung Galaxy z Fold2 5G            $83.33"+"\n"+
				"2. Samsung Galaxy Note 20 Ultra 5G     $54.16"+"\n"+
				"3. Motorola Edge +                                $41.66"+"\n"+
				"4LG Velvet 5G UW                                 $29.16"+"\n"+
				""+"\n"+
				"5. No service                            "+"\n"+
				"__________________________________________________"+"\n",
				"Phone Selections",
				JOptionPane.QUESTION_MESSAGE);
		phoneType = Integer.parseInt(inputString);
		
				inputString= JOptionPane.showInputDialog(null,
								"     Please Select Service Plan    " +"\n"+
								"     Monthly  Costs         " +"\n"+
								"_______________________________________" +"\n"+
								"Unlimited"+"\n"+
								"1.Start                    $35.00"+"\n"+
								"2.Play More            $45.00"+"\n"+
								"3.Get More             $55.00"+"\n"+
								""+"\n"+
								""+"\n"+
								"Shared Data"+"\n"+
								"4.S(5GB)                $55.00"+"\n"+
								"5.M(10GB)              $65.00"+"\n"+
								"\n"+
								"6. No service          "+"\n"+
								"____________________________________________"+"\n",
								JOptionPane.QUESTION_MESSAGE);
				servicePlan= Integer.parseInt(inputString);
				
				inputString= JOptionPane.showInputDialog(null,
						"Please Select Your Entertainment Service    " +"\n"+
						"            Monthly  Costs         " +"\n"+
						"_______________________________________" +"\n"+
						"1.Play More                               $6.99"+"\n"+
						"2.Hulu                                       $5.99"+"\n"+
						"3.Sports + Disney + Hulu       $13.99"+"\n"+
						""+"\n"+
						""+"\n"+
						"4. No service          "+"\n"+
						"____________________________________________"+"\n",
						JOptionPane.QUESTION_MESSAGE);
				entService= Integer.parseInt(inputString);
		
		//Choices choices choices
		switch(phoneType)
	{
		case 1:
		
			phoneLabel= "Samsung Galaxy z Fold2 5G";
			phoneCost = 83.33;
			++numberofSevices;
			break;
			
		
	    case 2:
	
			phoneLabel= "Samsung Galaxy Note 20 Ultra 5G";
			phoneCost = 54.16;
			++numberofSevices;
			break;
			
			
	    case 3:
	    	phoneLabel= "Motorola Edge+";
			phoneCost = 41.66;
			++numberofSevices;
			break;
	    	
	    	
	    case 4:
	    	phoneLabel= "LG Velvet 5G UW";
			phoneCost = 29.16;
			++numberofSevices;
			break;
	    
	}	
		switch(servicePlan) {
		case 1:
			planLabel ="Start";
			planCost = 35.00;
			++numberofSevices;
			break;
		
		case 2: 
				planLabel ="Play More";
				planCost= 45.00;
				++numberofSevices;
				break;
							
		case 3:
			planLabel="Get More";
			planCost= 55.00;
			++numberofSevices;
			break;
			
		
		case 4:
			planLabel="S";
			planCost=55.00;
			++numberofSevices;
			break;
			
		case 5:
			planLabel="M";
			planCost=65.00;
			++numberofSevices;
			break;
			
		}
		switch(entService) {
		    case 1:
		    	entLabel="Disney";
		    	entCost=5.99;
		    	++numberofSevices;
		    	break;
		    
		    case 2:
		    	entLabel="Hulu";
		    	entCost = 5.99;
		    	++numberofSevices;
		    	break;
		    
		    case 3:
		    	entLabel="Sports + Disney +Hulu";
		    	entCost=13.99;
		    	++numberofSevices;
		    	break;
		    			
				}
		double total = phoneCost+planCost+entCost;
		switch(numberofSevices) {
		
		case 1:
			discountLabel="%0";
			discount=0.00;
			break;
		
		case 2:
			discountLabel= "%15";
			discount = 0.15* total;
			break;
		
		case 3:
			discountLabel ="%20";
			discount= 0.20* total;
			break;
		}
	
	double finalCost = total - discount;
	total = Math.round((total*100.00) /100.00);
	finalCost = Math.round((finalCost *100.00)/100.00);
JOptionPane.showMessageDialog(null,
	"               CSC 229-Project 02               "+"\n"+
	"________________________________________________"+"\n"+
	"First Name   :"+firstName +"\n"+
	"Last Name   :"+lastName+"\n"+
	"Address      :"+address+"\n"+
	"                 "+ cityName+","+twoLetterStateCode+" "+zipCode+"\n"+
	"_______________________________________________"+"\n"+
	"                   Service List                "+"\n"+
	"_______________________________________________"+"\n"+
	"Phone                          :"+phoneLabel+"---"+phoneCost+"\n"+
	"Service Plan                :"+planLabel+"---"+planCost+"\n"+
	"Entertainment Service:"+entLabel+"---"+entCost+"\n"+
	"_________________________________________________"+"\n"+
	"                Total Cost     :"+total +"\n"+
	"                % Discount   :"+discountLabel+"\n"+
	"                Final Cost     :"+finalCost+"\n"+
	"__________________________________________________"+"\n",
	"Project 2 - Elvis", JOptionPane.INFORMATION_MESSAGE);
				

	}

}
