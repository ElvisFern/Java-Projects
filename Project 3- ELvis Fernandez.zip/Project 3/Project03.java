// File Dialog related imports
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
// Text File related imports
import java.io.File;
import java.util.Scanner;
import java.io.PrintWriter; 
import java.io.IOException;
import java.util.ArrayList;


public class Project03 {
	public static void main(String[]args) throws IOException
	{   
		Scanner inputFile = new Scanner("input");
		PrintWriter outputFile = new PrintWriter("output");
		
		//file-related Variables
		String inputFileName = "input";
		String inputFilePath ="input";
		String outputFileName = "input";
		String outputFilePath ="input";
		
		int fileSize = 0;
		int fileMinimum = Integer.MAX_VALUE;
		int fileMaximum = Integer.MIN_VALUE;
		int fileSum = 0;
		int fileTotal = 1;
		double fileAverage = 0.0;
		//Display Information on program
		JOptionPane.showMessageDialog(null,
				"                                  CSC 229          " +"\n"+
				"                                  File Processing          " +"\n"+
				"_________________________________________________________" +"\n"+
				"          Description:"+"This program reads a text file of integer data \n "
						+ "                              and creates an out text file with the same \n "
						+ "                              information plus minimum, maximum,total and \n"
						+ "                               average of data"+"\n"+
				"               Input      :"+"A text file of Integer values, file size is the \n"
						+ "                               first data item on the first line."+"\n"+
				"              Output     :"+"Entire content of input file, 10 data items/line \n"
						+ "                               plus statistics(minimum,maximum,total and average \n"
						+ "                               one/line"+"\n"+
				"________________________________________________________"+"\n",
				"Instructions",
				JOptionPane.INFORMATION_MESSAGE);
		
		//File dialog
		JFileChooser chooser = new JFileChooser();
	    chooser.setDialogTitle("Open Data File");
	    FileNameExtensionFilter filter = new FileNameExtensionFilter(
	            "Text Data Files", "txt");
	    chooser.setFileFilter(filter);
	    
	    //get input file path
        
        int returnVal = chooser.showOpenDialog(null);
		if( returnVal == JFileChooser.APPROVE_OPTION) 
		{
			inputFilePath = chooser.getSelectedFile().getPath();
			inputFileName = chooser.getSelectedFile().getName();
		}
		System.out.println(returnVal+"\n"+inputFilePath+"\n"+inputFileName);
		
		//get output file path
				chooser.setDialogTitle("Open Output File");
				returnVal = chooser.showSaveDialog(null); 
				if( returnVal == JFileChooser.APPROVE_OPTION) 
				{
					outputFilePath = chooser.getSelectedFile().getPath();
					outputFileName =chooser.getSelectedFile().getName();
				}
				
		
			inputFile= new Scanner(new File(inputFilePath));
			outputFile = new PrintWriter(outputFilePath);
			int intData;
			fileSize = inputFile.nextInt();
			outputFile.println(Integer.toString(fileSize));
			int fileVarCounter=0;
			ArrayList<String> fileVar = new ArrayList<String>();
			while (inputFile.hasNext())
			{
			
				intData=inputFile.nextInt();
				// write data to file
				// calculate minimum maximum and total
				fileSum+= intData;
				if(intData<fileMinimum) {
				    	fileMinimum= intData;
				    }
			    if (intData>fileMaximum) {
				    fileMaximum=intData;
				  }
			    fileVarCounter++;
			    String x = Integer.toString(intData);
			    fileVar.add(x);
				}
			
			fileAverage =fileSum/fileVarCounter; 
			// Write stats to output file
			outputFile.println("Min:"+fileMinimum+"\n"+"Max:"+fileMaximum+"\n"+"Total:"+fileSum+"\n"+"Average:"+fileAverage);
			outputFile.println(fileVar);
			outputFile.close();
			// show results
			JOptionPane.showMessageDialog(null,
					"                                  CSC 229          " +"\n"+
					"                                  File Processing          " +"\n"+
					"_________________________________________________________" +"\n"+
					"          Input File Name       :"+inputFileName+"\n"+
					"          Output File Name    :"+outputFileName+"\n"+
					"          File Size                   :"+fileSize+"\n"+
					"_________________________________________________________"+"\n"+
					"          Minimum              :"+fileMinimum+"\n"+
					"          Maximum              :"+fileMaximum+"\n"+
					"          Total                     :"+fileSum+"\n"+
					"          Average                :"+fileAverage+"\n"+
					"_________________________________________________________"+"\n",
							"Instructions",
							JOptionPane.INFORMATION_MESSAGE); 
					}
	}


