import javax.swing.JOptionPane;

public class Cube {
	//data memebers
	private int xTopLeft;
	private int yTopLeft;
	private int side;
	
	//constructors
	public Cube() // no arg
	{
		xTopLeft= 100;
		yTopLeft= 100;
		side=100;
	}
	public Cube(int x, int y, int s) {
		xTopLeft= x;
		yTopLeft= y;
		side=s;
	}
	// accesors
	public int getxTopLeft() {return xTopLeft;}
	public int getyTopLeft() {return yTopLeft;}
	public int getSide() {return side;}
	
	public int getSurface()
	{
		return 6*side*side;
	}
	
	public int getVolume()
	{
		return side*side*side;
	}
	
	public void getAttributes() {
		String input;
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"XTopLeft Corner of Cube", JOptionPane.INFORMATION_MESSAGE);
		xTopLeft = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"YTopLeft Corner of Cube", JOptionPane.INFORMATION_MESSAGE);
		yTopLeft = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Side of Cube", JOptionPane.INFORMATION_MESSAGE);
		side = Integer.parseInt(input);
		
	}

}
