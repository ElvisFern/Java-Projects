import javax.swing.JOptionPane;

public class Diamond {
	// Data members
	private int X;
	private int Y;
	private int Width;
	private int Height;
	
	public Diamond() // no arg constructor
	{
		int X=0;
		int Y =0;
		int Widtth =0;
		int Height =0;
	}
	public Diamond(int x, int y, int w, int h)
	{
		int X=x;
		int Y =y;
		int Widtth =w;
		int Height =h;
	}
	
	public int getX() {return X;}
	public int getY() {return Y;}
	public int getWidth() {return Width;}
	public int getHeight() {return Height;}
	
	public double getArea()
	{
		return (Width*Height)/2.0;
	}
	public double getPerimeter()  // Perimeter is P=2* sqrt(w^2+h^2)
	{
		double w2 = Width*Width;
		double h2= Height*Height;
		return 2*Math.sqrt(w2+h2);
	}
	public void getAttributes() {
		String input;
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"X Center of Diamond", JOptionPane.INFORMATION_MESSAGE);
		X = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Y Center of Diamond", JOptionPane.INFORMATION_MESSAGE);
		Y = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Width of Diamond", JOptionPane.INFORMATION_MESSAGE);
		Width = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Height of Diamond", JOptionPane.INFORMATION_MESSAGE);
		Height = Integer.parseInt(input);
	}
}
