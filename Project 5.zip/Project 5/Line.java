import javax.swing.JOptionPane;

public class Line {
	
	//Data member
	private int xStart;
	private int yStart;
	private int xEnd;
	private int yEnd;
	
	// public constructors
	public Line()   //no arg constructor
	{
		int xStart=0;
		int yStart=0;
		int xEnd=0;		
		int yEnd=0;
	}
	public Line(int x, int y, int z, int w) {
		int xStart=x;
		int yStart=y;
		int xEnd=z;		
		int yEnd=w;
	}
	
	// accesors
		public int getxStart() {return xStart;}
		public int getyStart() {return yStart;}
		public int getxEnd() {return xEnd;}
		public int getyEnd() {return yEnd;}
	
		public double getLength() {              //Distance formula bewteen 2 points
			                                     //d = sqrt((x2-x1)^2+(y2-y2)^2)
			int point1= xEnd -xStart;
			int point2= yEnd -yStart;
			return Math.sqrt((point1*point1)+(point2*point2));
		}
		public void getAttributes() {
			String input;
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"X1 coordinate of Line", JOptionPane.INFORMATION_MESSAGE);
			xStart = Integer.parseInt(input);
			
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"Y1 coordinate of Line", JOptionPane.INFORMATION_MESSAGE);
			yStart = Integer.parseInt(input);
			
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"X2 coordinate of Line", JOptionPane.INFORMATION_MESSAGE);
			xEnd = Integer.parseInt(input);
			
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"Y2 coordinate of Line", JOptionPane.INFORMATION_MESSAGE);
			yEnd = Integer.parseInt(input);
		}
}


