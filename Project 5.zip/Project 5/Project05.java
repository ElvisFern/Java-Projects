import javax.swing.JOptionPane;

public class Project05 {

	public static void main(String[] args) 
	{
		menu();
		
	}
	public static void menu() 
	{
		String input;
		int option =0;
		Object o="";
		while(option!= 7)
		{
		input = JOptionPane.showInputDialog(null,
				"Geometric Shapes"+"\n"+
				"_________________________________________"+"\n"+
				"  		Select a Shape by Entering"+"\n"+
				"	 the Number Associated with Shape"+"\n"+
				"  		Press7 to Exit the program"+"\n"+
				"__________________________________________"+"\n"+
				"		1. Line"+"\n"+
				"		2. Triangle"+"\n"+
				"		3. Rectangle"+"\n"+
				"		4. Diamond"+"\n"+
				"___________________________________________"+"\n"+
				"      Three Dimensional shapes"+"\n"+
				"____________________________________________"+"\n"+
				"		5. Triangular Prism"+"\n"+
				"		6. Cube"+"\n"+
				"_____________________________________________"+"\n"+
				"		7. EXIT"+"\n"+
				"________________________________________________",
				"Math Series",JOptionPane.INFORMATION_MESSAGE
				);
		option= Integer.parseInt(input);
		//Calculation and displays based on option selected from the menu
		switch(option)
		{
		case 1:
		{
			 //line
			Line l = new Line();
			l.getAttributes();
			o=l;
			break;
		}
		case 2:
		{
			//triangle
			Triangle t = new Triangle();
			t.getAttributes();
			o=t;
				break;
		}
		case 3:{
			
			//rectangle
			Rectangle r = new Rectangle();
			r.getAttributes();
			o=r;
			 break;
		}
		
		case 4:{
			//Diamond
			Diamond d = new Diamond();
			d.getAttributes();
			o=d;
			break;
		}
		case 5:
		{
			TriangularPrism tp = new TriangularPrism();
			tp.getAttributes();
			o=tp;
			break;
		}
		case 6:
		{   //Cube 
			Cube c = new Cube();
			c.getAttributes();
			o=c;
			break;
		}
		case 7:
		{
			//exit
			JOptionPane.showMessageDialog(null,
					"Good Bye",
					"Thank You for Using The Geometric Shapes",JOptionPane.INFORMATION_MESSAGE
					);
			System.exit(0);
			break;
			}
		default:
			JOptionPane.showMessageDialog(null, 
					"Incorrect Input Value, Please Enter a Number Between 1 and 5",
					"ERROR",JOptionPane.ERROR_MESSAGE);
		}//end of switch
		displayResult(option,o);
	   }//end of while;
	}
	public static void displayResult(int option, Object o)
	{
		switch(option)
		{
			case 1:
			{//Line
				Line l= (Line) o;
				JOptionPane.showMessageDialog(null, 
						"      Line Properties"+"\n"+
						"_____________________________________________"+"\n"+
						"	First Point  = ("+l.getxStart()+","+l.getyStart()+")"+"\n"+
						"			Second Point = ("+l.getxEnd()+","+l.getxEnd()+")"+"\n"+
						"			Length		 =  "+l.getLength()+"\n"+
						"______________________________________________"+"\n",
						"Line", JOptionPane.INFORMATION_MESSAGE);
			
				break;
			}
			case 2:
			{
				Triangle tr= (Triangle) o;
				JOptionPane.showMessageDialog(null, 
						"   	Triangle Properties"+"\n"+
						"_______________________________________________"+"\n"+
						"  First Point = ("+tr.getX1()+","+tr.getY1()+")"+"\n"+
						"  Second Point = ("+tr.getX2()+","+tr.getY2()+")"+"\n"+
						"  Third Point = ("+tr.getX3()+","+tr.getY3()+")"+"\n"+
						"				  Side 1 = "+tr.getSide1()+"\n"+
						"				  Side 2 = "+tr.getSide2()+"\n"+
						"				  Side 3 = "+tr.getSide3()+"\n"+
						"				  Perimeter = "+tr.getPerimeter()+"\n"+
						" 				   Area = "+tr.getArea()+"\n"+
						"________________________________________________"+"\n",
						"Triangle", JOptionPane.INFORMATION_MESSAGE);
				break;
			}
			case 3:
			{
				Rectangle r= (Rectangle) o;
				JOptionPane.showMessageDialog(null, 
						"         Rectangle Properties"+"\n"+
						"______________________________________________"+"\n"+
						"				TopLeft Corner = ("+r.getxTopLeft()+","+r.getyTopLeft()+")"+"\n"+
						"				Widht = "+r.getWidth()+"\n"+
						"				Height = "+r.getHeight()+"\n"+
						"				Perimiter = "+r.getPerimeter()+"\n"+
						" 			  Area = "+r.getArea()+"\n"+
						"_______________________________________________"+"\n",
						"Rectangle", JOptionPane.INFORMATION_MESSAGE);
			
				break;	
			}
			case 4:{
				Diamond d= (Diamond) o;
				JOptionPane.showMessageDialog(null, 
						"        Diamond Properties"+"\n"+
						"____________________________________________"+"\n"+
						"	        	Center = ("+d.getX()+","+d.getY()+")"+"\n"+
						"				Widht = "+d.getWidth()+"\n"+
						"				Height = "+d.getHeight()+"\n"+
						"				Perimiter = "+d.getPerimeter()+"\n"+
						" 			  Area = "+d.getArea()+"\n"+
						"___________________________________________"+"\n",
						"Diamond", JOptionPane.INFORMATION_MESSAGE);
				}
			break;
			case 5:
			{
				TriangularPrism tp= (TriangularPrism) o;
				JOptionPane.showMessageDialog(null, 
						"        Prism Properties"+"\n"+
						"__________________________________________"+"\n"+
						"				Base Corner 1 = ("+tp.getX1()+","+tp.getY1()+")"+"\n"+
						"				Base Corner 2 = ("+tp.getX2()+","+tp.getY2()+")"+"\n"+
						"				Base Corner 3 = ("+tp.getX3()+","+tp.getY3()+")"+"\n"+
						"				Height = "+tp.getHeight()+"\n"+
						"				Surface = "+tp.getSurface()+"\n"+
						" 			  Volume = "+tp.getVolume()+"\n"+
						"___________________________________________"+"\n",
						"Prism", JOptionPane.INFORMATION_MESSAGE);
				break;
			}
			case 6:{
				Cube tc= (Cube) o;
				JOptionPane.showMessageDialog(null, 
						"        Cube Properties                   "+"\n"+
						"__________________________________________"+"\n"+
						"TopLeft Corner = ("+tc.getxTopLeft()+","+tc.getyTopLeft()+")"+"\n"+
						"				Side = "+tc.getSide()+"\n"+
						"				Perimiter = "+tc.getSurface()+"\n"+
						"Area = "+tc.getVolume()+"\n"+
						"___________________________________________"+"\n",
						"Cube",JOptionPane.INFORMATION_MESSAGE);
				break;
				
				
			}
             }
		 
	 }
}	