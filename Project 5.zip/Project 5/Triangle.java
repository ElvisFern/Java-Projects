import javax.swing.JOptionPane;

public class Triangle {
	//Data members
	private int x1;
	private int y1;
	private int x2;
	private int y2;
	private int x3;
	private int y3;
	
	//Constructors
	public Triangle()   //no-argument constructor
	{
		 int x1 =0;
		 int y1=0;
		 int x2=0;
		 int y2=0;
		 int x3=0;
		 int y3=0;
	}
	public Triangle(int x, int y, int w, int z, int a, int b )  //constructor
	{
		 int x1 =x;
		 int y1=y;
		 int x2=w;
		 int y2=z;
		 int x3=a;
		 int y3=b;
	}
	//acessors
	public int getX1(){return x1;}
	public int getY1(){return y1;}
	public int getX2(){return x2;}
	public int getY2(){return y2;}
	public int getX3(){return x3;}
	public int getY3(){return y3;}
	
	public double getPerimeter() {
		
		double side1 = getSide1();
		double side2 = getSide2();
		double side3 = getSide3();
		double perimeter = side1 + side2 +side3;
		return perimeter;
	}
	public double getArea() {
		double side1 = getSide1();
		double side2 = getSide2();
		double side3 = getSide3();
		double S = (side1+side2+side3)/2;
		return Math.sqrt(S*(S-side1)*(S-side2)*(S-side3));
	}
	public double getSide1() {
		double point1 =(x1-x2)*(x1-x2);
		double point2= (y1-y2)*(y1-y2);
		double side= Math.sqrt(point1 + point2);
		return side;
	}
	public double getSide2(){
		double point1 =(x1-x3)*(x1-x3);
		double point2= (y1-y3)*(y1-y3);
		double side2= Math.sqrt(point1 + point2);
		return side2;
	}
	public double getSide3(){
		double point1 =(x2-x3)*(x2-x3);
		double point2= (y2-y3)*(y2-y3);
		double side3= Math.sqrt(point1 + point2);
		return side3;
	}
	public void getAttributes() {
		String input;
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"X1 Corner of Triangle", JOptionPane.INFORMATION_MESSAGE);
		x1 = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Y1 Corner of Triangle", JOptionPane.INFORMATION_MESSAGE);
		y1 = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"X2 Corner of Triangle", JOptionPane.INFORMATION_MESSAGE);
		x2 = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Y2 Corner of Triangle", JOptionPane.INFORMATION_MESSAGE);
		y2 = Integer.parseInt(input);
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"X3 Corner of Triangle", JOptionPane.INFORMATION_MESSAGE);
		x3 = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Y3 Corner of Triangle", JOptionPane.INFORMATION_MESSAGE);
		y3 = Integer.parseInt(input);
	}
}
