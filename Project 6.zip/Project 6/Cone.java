import javax.swing.JOptionPane;

public class Cone {
	
	//Data Members
		private int X1;
		private int Y1;
		private int Radius;
		private int Height;
		
		//No Argument Constructor
		public Cone() {
			int x =0;
			int y =0;
			int Radius =0;
			int Height=0;
		}
		//Argument Constructor
		public Cone(int r, int x, int y, int h){
			int X1 =x;
			int Y1 =y;
			int Radius =r;
			int Height=h;
		}
		
		//Accesors
		public int getRadius(){return Radius;}
		public int getX(){return X1;}
		public int getY(){return Y1;}
		public int getHeight(){return Height;}
		
		//Calculate Surface  SA= pi*r(r+sqrt(height^2*r^2))
		
		public double getSurface(){
			return Math.PI*Radius*(Radius+Math.sqrt((Height*Height)+Radius*Radius));
			}
		
		// Calculate Volume of a cone V= Pi*R^2*h/3
		
		public double getVolume() {
			return Math.PI*Math.pow(Radius, 2)*Height/3;
		}
		public void getAttributes() {
			String input;
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"X Center of Cone", JOptionPane.INFORMATION_MESSAGE);
			X1 = Integer.parseInt(input);
			
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"Y Center of Cone", JOptionPane.INFORMATION_MESSAGE);
			Y1 = Integer.parseInt(input);
			
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"Radius of Cone", JOptionPane.INFORMATION_MESSAGE);
			Radius = Integer.parseInt(input);
			
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"Height of Cone", JOptionPane.INFORMATION_MESSAGE);
			Height = Integer.parseInt(input);
		}

}
