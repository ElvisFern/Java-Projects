import javax.swing.JOptionPane;

public class Cylinder {
	//Data Members
			private int X;
			private int Y;
			private int radius;
			private int height;
			
			//No Argument Constructor
			public Cylinder() {
				int x =0;
				int y =0;
				int radius =0;
				int height=0;
			}
			//Argument Constructor
			public Cylinder(int r, int x, int y, int h){
				int X =x;
				int Y =y;
				int radius =r;
				int height=h;
			}
			
			//Accesors
			public int getRadius(){return radius;}
			public int getX(){return X;}
			public int getY(){return Y;}
			public int getHeight(){return height;}
			
			//Calculate Surface  SA= 2*pi*r*h+2*pi*r^2
			
			public double getSurface(){
				return 2*Math.PI*radius*height+2*Math.PI*Math.pow(radius, 2);
				}
			
			// Calculate Volume of a cylinder V= Pi*R^2*h
			
			public double getVolume() {
				return Math.PI*Math.pow(radius, 2)*height;
			}
			
			public void getAttributes() {
				String input;
				input= JOptionPane.showInputDialog(null,
						"Please Enter a Positive Integer",
						"X Center of Cylinder", JOptionPane.INFORMATION_MESSAGE);
				X = Integer.parseInt(input);
				
				input= JOptionPane.showInputDialog(null,
						"Please Enter a Positive Integer",
						"Y Center of Cylinder", JOptionPane.INFORMATION_MESSAGE);
				Y = Integer.parseInt(input);
				
				input= JOptionPane.showInputDialog(null,
						"Please Enter a Positive Integer",
						"Radius of Cylinder", JOptionPane.INFORMATION_MESSAGE);
				radius = Integer.parseInt(input);
				
				input= JOptionPane.showInputDialog(null,
						"Please Enter a Positive Integer",
						"Height of Cylinder", JOptionPane.INFORMATION_MESSAGE);
				height = Integer.parseInt(input);
				
			}		

}


