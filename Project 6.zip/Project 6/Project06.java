import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JOptionPane;
import java.awt.Color;

public class Project06 extends Frame implements ActionListener {
	
	//Objects
	Line l;
	Triangle tr;
	Rectangle r;
	Diamond d;
	TriangularPrism tp;
	Cube c;
	Sphere S;
	Cone Co;
	Cylinder y;
	String command = "";
	
	
	//Colors
	JColorChooser colorChooser = new JColorChooser();
	Color backgroundColor = new Color(0,0,0);
	Color foregroundColor = new Color(255,255,255);
	
	public static void main(String[] args)
	{
		Frame frame =new Project06();
		frame.setResizable(true);
		frame.setSize(1000,840);
		frame.setVisible(true);
		
	}
	public Project06()
	{
		setTitle("Graphics - Fernandez");
		
		//Create Menu
		
		MenuBar mb = new MenuBar();
		setMenuBar(mb);
		
		Menu fileMenu = new Menu("File");
		mb.add(fileMenu);
		
		MenuItem miAbout = new MenuItem("About");
		miAbout.addActionListener(this);
		fileMenu.add(miAbout);
		
		MenuItem miColor = new MenuItem("Color");
		miColor.addActionListener(this);
		fileMenu.add(miColor);
		
		MenuItem miExit = new  MenuItem("Exit");
		miExit.addActionListener(this);
		fileMenu.add(miExit);
		
		//2D Shapes Menu
		
		Menu twoDMenu = new Menu("2D Shapes");
		mb.add(twoDMenu);
		
		MenuItem miLine = new MenuItem("Line");
		miLine.addActionListener(this);
		twoDMenu.add(miLine);
		
		MenuItem miTriangle = new MenuItem("Triangle");
		miTriangle.addActionListener(this);
		twoDMenu.add(miTriangle);
		
		MenuItem miRectangle = new MenuItem("Rectangle");
		miRectangle.addActionListener(this);
		twoDMenu.add(miRectangle);
		
		MenuItem miDiamond = new MenuItem("Diamond");
		miDiamond.addActionListener(this);
		twoDMenu.add(miDiamond);
		
		// 3D Shapes Menu
		
		
		Menu threeDMenu = new Menu("3D Shapes");
		mb.add(threeDMenu);
		
		MenuItem miTriangularPrism = new MenuItem("TriangularPrism");
		miTriangularPrism.addActionListener(this);
		threeDMenu.add(miTriangularPrism);
		
		MenuItem miCube = new MenuItem("Cube");
		miCube.addActionListener(this);
		threeDMenu.add(miCube);
		
		MenuItem miSphere = new MenuItem("Sphere");
		miSphere.addActionListener(this);
		threeDMenu.add(miSphere);
		
		MenuItem miCone = new MenuItem("Cone");
		miCone.addActionListener(this);
		threeDMenu.add(miCone);
		
		MenuItem miCylinder = new MenuItem("Cylinder");
		miCylinder.addActionListener(this);
		threeDMenu.add(miCylinder);
		// End program when window is closed
	
	
	WindowListener l = new WindowAdapter()
			{
				public void windowClosing(WindowEvent ev)
				{
					System.exit(0);
				}
				public void windowActivated(WindowEvent ev)
				{
					repaint();
				}
				public void windowStateChanged(WindowEvent ev)
				{
					repaint();
				}
			};
	ComponentListener k = new ComponentAdapter()
			{
				public void componentResized(ComponentEvent e)
				{
					repaint();
				}
			};
			// registers listeners
			this.addWindowListener(l);
			this.addComponentListener(k);
	}
//*****************************************************************************
//*called by windows manager whenever the application window performs an action*
//*(select a menu item, close, resize,.....                                    *
//*****************************************************************************	

public void actionPerformed(ActionEvent ev)
	{
	// figure out which command was issued
	
	command = ev.getActionCommand();
	
	//take action accordingly
	switch(command)
	{
	//File Menu
	case "About":
		{
			repaint();
			break;
		}
	case "Exit":
	{
		System.exit(0);
	}
	
	case "Color":
	{
		backgroundColor = JColorChooser.showDialog(null,"Choose Background Color", colorChooser.getBackground());
		foregroundColor = JColorChooser.showDialog(null, "Choose Drawing Color", colorChooser.getBackground());
		repaint();
		break;
	}
	//2D Shapes
	case "Line":
	{
		l = new Line();
		l.getAttributes();
		repaint();
		break;
	}
	
	case "Triangle":
	{
		tr = new Triangle();
		tr.getAttributes();
		repaint();
		break;
	}
	
	case "Rectangle":
	{
		r = new Rectangle();
		r.getAttributes();
		repaint();
		break;
	}
	case "Diamond":
	{
		d = new Diamond();
		d.getAttributes();
		repaint();
		break;
	}
	//3D Shapes
	case "TriangularPrism":
	{
		tp = new TriangularPrism();
		tp.getAttributes();
		repaint();
		break;
	}
	case "Cube":
	{
		c = new Cube();
		c.getAttributes();
		repaint();
		break;
	}
	case "Sphere":{
		S = new Sphere();
		S.getAttributes();
		repaint();
		break;
	}
	case "Cone":{
		Co = new Cone();
		Co.getAttributes();
		repaint();
		break;
	}
	case "Cylinder":{
		y = new Cylinder();
		y.getAttributes();
		repaint();
		break;
	}
	
	}
 }
//**********************************************
//**called by repaint() to redraw the screen  **
//**********************************************
public void paint(Graphics g)
{
	//Check Command issued, take action accordingly
	switch(command)
	{
	case "About":{
		g.drawString("Geometric Shapes",400,100);
		g.drawLine(350,120, 550, 120);
		g.drawString(" This program supports the entry of values of primary attributes and calculation of secondary",200,140);
		g.drawString(" attributes sides, angles, perimeter, area, surface, volume of the following shapes: ", 200, 160);
		
		g.drawString(" 1.      Line", 400, 200);
		g.drawString(" 2.      Triangle", 400, 220);
		g.drawString(" 3.      Rectangle", 400, 240);
		g.drawString(" 4.      Diamond", 400, 260);
		g.drawString(" 5.      Trinagular Prism", 400, 280);
		g.drawString(" 6.      Cube",400,300);
		break;
	 }
	case "Color":{
		this.setBackground(backgroundColor);
		this.setForeground(foregroundColor);
		break;
	 }
	//2D shapes
	case "Line":
	 {
		// Draw variable display box
			g.drawString("Line Properties", 120, 110);
			g.drawLine(75, 120, 260, 120);
			g.drawString("First Point", 100, 140);
			g.drawString("=("+Integer.toString(l.getxStart())+
					","+Integer.toString(l.getyStart())+")",
					185, 140);
			g.drawString("Second Point", 100, 160);
			g.drawString("=("+Integer.toString(l.getxEnd())+","+Integer.toString(l.getxEnd())+")",
					185, 160);
			g.drawString("Length", 100, 180);
			g.drawString("="+Double.toString(roundDigits(l.getLength(),2)),
					185, 180);
			g.drawRect(75, 90, 185, 100);
			// Draw Shape
			g.drawLine(l.getxStart(), l.getyStart(), l.getxEnd(), l.getyEnd());
			//Add labels
			g.drawString("("+Integer.toString(l.getxStart())+
					","+Integer.toString(l.getyStart())+")",
					l.getxStart(), l.getyStart());
			g.drawString("("+Integer.toString(l.getxEnd())+
					","+Integer.toString(l.getyEnd())+")",
					l.getxEnd(), l.getyEnd());
			g.drawString(Double.toString(roundDigits(l.getLength(),2)),
					(l.getxStart()+l.getxEnd())/2, (l.getyStart()+l.getyEnd())/2);
			
			break;
	 }
	case "Triangle":{
		// Draw variable display box
		g.drawString("Triangle Properties", 120, 100);
		g.drawLine(75, 120, 260, 120);
		g.drawString("Corners", 150, 135);
		g.drawLine(75, 140, 260, 140);
		g.drawString("("+Integer.toString(tr.getX1())+
				","+Integer.toString(tr.getY1())+")",
				145, 160);
		g.drawString("("+Integer.toString(tr.getX2())+","+Integer.toString(tr.getY2())+")",
				145, 180);
		g.drawString("("+Integer.toString(tr.getX3())+","+Integer.toString(tr.getY3())+")",
				145, 200);
		g.drawLine(75, 220, 260, 220);
		g.drawString("Sides", 150, 235);
		g.drawLine(75, 240, 260, 240);
		g.drawString(Double.toString(roundDigits(tr.getSide1(),2)),
				145, 260);
		g.drawString(Double.toString(roundDigits(tr.getSide2(),2)),
				145, 280);
		g.drawString(Double.toString(roundDigits(tr.getSide3(),2)),
				145, 300);
		g.drawLine(75, 320, 260, 320);
		g.drawString("Perimeter", 100, 340);
		g.drawString("=("+Double.toString(roundDigits(tr.getPerimeter(),2))+")",
				160, 340);
		g.drawString("Area", 100, 360);
		g.drawString("=("+Double.toString(roundDigits(tr.getArea(),2))+")",
				160, 360);
		g.drawRect(75, 70, 185, 300);
		//Draw Shape
		g.drawLine(tr.getX1(), tr.getY1(), tr.getX2(), tr.getY2());
		g.drawLine(tr.getX1(), tr.getY1(), tr.getX3(), tr.getY3());
		g.drawLine(tr.getX2(), tr.getY2(), tr.getX3(), tr.getY3());
		//add labels
		g.drawString("("+Integer.toString(tr.getX1())+
				","+Integer.toString(tr.getY1())+")",tr.getX1(),tr.getY1()+10);
		g.drawString("("+Integer.toString(tr.getX2())+","+Integer.toString(tr.getY2())+")",
				tr.getX2(),tr.getY2()+10);
		g.drawString("("+Integer.toString(tr.getX3())+","+Integer.toString(tr.getY3())+")",
				tr.getX3(),tr.getY3()+10);
		g.drawString(Double.toString(roundDigits(tr.getSide1(),2)), (tr.getX2()+tr.getX1())/2, ((tr.getY2()+tr.getY3())/2)-100);
		g.drawString(Double.toString(roundDigits(tr.getSide2(),2)), (tr.getX2()+tr.getX3())/2, (tr.getY2()+tr.getY3())/2);
		g.drawString(Double.toString(roundDigits(tr.getSide3(),2)),(tr.getX3()+tr.getX1())/2,(tr.getY3()+tr.getY1())/2);
		
		break;
	   }
	case "Rectangle":{
		// Draw variable display box
		g.drawString("Rectangle Properties", 110, 110);
		g.drawLine(75, 120, 260, 120);
		g.drawString("TopLeft Corner", 100, 140);
		g.drawString("=("+Integer.toString(r.getxTopLeft())+
				","+Integer.toString(r.getyTopLeft())+")",
				185, 140);
		g.drawString("Width", 100, 160);
		g.drawString("="+Integer.toString(r.getWidth()),
				185, 160);
		g.drawString("Height", 100, 180);
		g.drawString("="+Integer.toString(r.getHeight()),
				185, 180);
		g.drawString("Perimeter", 100, 200);
		g.drawString("="+Integer.toString(r.getPerimeter()),
				185, 200);
		g.drawString("Area", 100, 220);
		g.drawString("="+Integer.toString(r.getArea()),
				185, 220);
		g.drawRect(75, 90, 185, 140);
		//Draw Shape
		g.drawRect(r.getxTopLeft(), r.getyTopLeft(), r.getWidth(), r.getHeight());
		// add labels
		g.drawString("("+Integer.toString(r.getxTopLeft())+
				","+Integer.toString(r.getyTopLeft())+")", r.getxTopLeft()-20, r.getyTopLeft()-10);
		g.drawString(Integer.toString(r.getHeight()),
				r.getxTopLeft()-35, r.getyTopLeft()+r.getHeight()/2);
		g.drawString(Integer.toString(r.getWidth()), r.getxTopLeft()+r.getWidth()/2, r.getyTopLeft()-10);
		break;
	 }
	case "Diamond":
	{
		// Draw variable display box
					g.drawString("Diamond Properties", 110, 110);
					g.drawLine(75, 120, 260, 120);
					g.drawString("Center", 100, 140);
					g.drawString("=("+Integer.toString(d.getX())+
							","+Integer.toString(d.getY())+")",
							185, 140);
					g.drawString("Width", 100, 160);
					g.drawString("="+Integer.toString(d.getWidth()),
							185, 160);
					g.drawString("Height", 100, 180);
					g.drawString("="+Integer.toString(d.getHeight()),
							185, 180);
					g.drawString("Perimeter", 100, 200);
					g.drawString("="+Double.toString(roundDigits(d.getPerimeter(),2)),
							185, 200);
					g.drawString("Area", 100, 220);
					g.drawString("="+Double.toString(d.getArea()),
							185, 220);
					g.drawRect(75, 90, 185, 140);
					// Draw Shape
					g.drawLine(d.getX(), d.getY(), d.getX(), d.getY()+(d.getHeight()/2));
					g.drawLine(d.getX(), d.getY(), d.getX(), d.getY()-(d.getHeight()/2));
					g.drawLine(d.getX(), d.getY(), d.getX()+(d.getWidth()/2), d.getY());
					g.drawLine(d.getX(), d.getY(), d.getX()-(d.getWidth()/2), d.getY());
					g.drawLine(d.getX()-(d.getWidth()/2), d.getY(),d.getX(), d.getY()-(d.getHeight()/2));
					g.drawLine(d.getX()-(d.getWidth()/2), d.getY(),d.getX(), d.getY()+(d.getHeight()/2));
					g.drawLine(d.getX()+(d.getWidth()/2), d.getY(),d.getX(), d.getY()-(d.getHeight()/2));
					g.drawLine(d.getX()+(d.getWidth()/2), d.getY(),d.getX(), d.getY()+(d.getHeight()/2));
					
					//add labels
					g.drawString("("+Integer.toString(d.getX())+
							","+Integer.toString(d.getY())+")",
							d.getX()-20, d.getY()+20);
					g.drawString(Integer.toString(d.getHeight()),
							d.getX()+10,(d.getY()-(d.getY()-d.getHeight())/2)+30);
					g.drawString(Integer.toString(d.getWidth()),
							((d.getX()+(d.getWidth()/2))+d.getX())/2, d.getY()-10);
		break;
	}
	
	//3D shapes
	case "TriangularPrism":
	 {
		// Draw variable display box
			g.drawString("Prism Properties", 115, 120);
			g.drawLine(80, 140, 260, 140);
			g.drawString("Corner 1", 105, 160);
			g.drawString("=("+Integer.toString(tp.getX1())+
					","+Integer.toString(tp.getY1())+")",
					185, 160);
			g.drawString("Corner 2", 105, 180);
			g.drawString("=("+Integer.toString(tp.getX2())+
					","+Integer.toString(tp.getY2())+")",
					185, 180);
			g.drawString("Corner 3", 105, 200);
			g.drawString("=("+Integer.toString(tp.getX3())+
					","+Integer.toString(tp.getY3())+")",
					185, 200);
			g.drawString("Height", 105, 220);
			g.drawString("=("+Integer.toString(tp.getHeight())+")",
					185, 220);
			g.drawString("Surface", 105, 240);
			g.drawString("=("+Double.toString(roundDigits(tp.getSurface(),2))+")",
					185, 240);
			g.drawString("Volume", 105, 260);
			g.drawString("=("+Double.toString(roundDigits(tp.getVolume(),1))+")",
					185, 260);
			g.drawRect(65, 90, 210, 180);
			// Draw Shape
			g.drawLine(tp.getX1(), tp.getY1(), tp.getX2(), tp.getY2());
			g.drawLine(tp.getX1(), tp.getY1(), tp.getX3(), tp.getY3());
			g.drawLine(tp.getX2(), tp.getY2(), tp.getX3(), tp.getY3());
			g.drawLine(tp.getX1(), tp.getY1(), tp.getX1(), tp.getY1()-getHeight()/4);
			g.drawLine(tp.getX2(), tp.getY2(), tp.getX2(), tp.getY2()-getHeight()/4);
			g.drawLine(tp.getX3(), tp.getY3(), tp.getX3(), tp.getY3()-getHeight()/4);
			g.drawLine(tp.getX1(), tp.getY1()-getHeight()/4,tp.getX2(), tp.getY2()-getHeight()/4);
			g.drawLine(tp.getX2(), tp.getY2()-getHeight()/4,tp.getX3(), tp.getY3()-getHeight()/4);
			g.drawLine(tp.getX3(), tp.getY3()-getHeight()/4,tp.getX1(), tp.getY1()-getHeight()/4);
			//Add Labels
			g.drawString("("+Integer.toString(tp.getX1())+
					","+Integer.toString(tp.getY1())+")",tp.getX1(),tp.getY1()+10);
			g.drawString("("+Integer.toString(tp.getX2())+
					","+Integer.toString(tp.getY2())+")",tp.getX2(),tp.getY2()+10);
			g.drawString("("+Integer.toString(tp.getX3())+
					","+Integer.toString(tp.getY3())+")",tp.getX3(),tp.getY3()+10);
			g.drawString(Integer.toString(tp.getHeight()),tp.getX1(),(tp.getY1()+(tp.getY1()-tp.getHeight()))/2);
			break;
	 }
	
	case "Cube":
	 {
		// Draw variable display box
			g.drawString("Cube Properties", 110, 110);
			g.drawLine(75, 120, 260, 120);
			g.drawString("TopLeft Corner", 100, 140);
			g.drawString("=("+Integer.toString(c.getxTopLeft())+
					","+Integer.toString(c.getyTopLeft())+")",
					185, 140);
			g.drawString("Side", 100, 160);
			g.drawString("="+Integer.toString(c.getSide()),
					185, 160);
			g.drawString("Surface", 100, 180);
			g.drawString("="+Integer.toString(c.getSurface()),
					185, 180);
			g.drawString("Volume", 100, 200);
			g.drawString("="+Integer.toString(c.getVolume()),
					185, 200);
			g.drawRect(75, 90, 185, 140);
			// Draw Shape
			g.drawRect(c.getxTopLeft(), c.getyTopLeft(), c.getSide(),c.getSide());
			g.drawLine(c.getxTopLeft(), c.getyTopLeft(), c.getxTopLeft()+c.getSide()/4,
					c.getyTopLeft()-c.getSide()/4);
			g.drawLine(c.getxTopLeft()+c.getSide()/4,c.getyTopLeft()-c.getSide()/4,
					(c.getxTopLeft()+c.getSide()/4)+(c.getSide()),c.getyTopLeft()-c.getSide()/4);
			g.drawLine(c.getxTopLeft()+c.getSide(), c.getyTopLeft(),
					c.getxTopLeft()+c.getSide()/4+(c.getSide()), c.getyTopLeft()-c.getSide()/4);
			g.drawLine(c.getxTopLeft()+c.getSide()/4+(c.getSide()), c.getyTopLeft()-c.getSide()/4,
					(c.getxTopLeft()+c.getSide()/4)+(c.getSide()), (c.getyTopLeft()-c.getSide()/4)+c.getSide());
			g.drawLine(c.getxTopLeft()+c.getSide(), c.getyTopLeft()+c.getSide(),
					(c.getxTopLeft()+c.getSide()/4)+(c.getSide()), (c.getyTopLeft()-c.getSide()/4)+c.getSide());
			//Add Labels
			g.drawString("("+Integer.toString(c.getxTopLeft())+
					","+Integer.toString(c.getyTopLeft())+")",c.getxTopLeft()-10,c.getyTopLeft()-10);
			g.drawString(Integer.toString(c.getSide()), c.getxTopLeft()-20, c.getyTopLeft()+c.getSide()/2);
			
			
			break;
	 }
	 case "Sphere":
	 {
		// Draw variable display box
			g.drawString("Sphere Properties", 115, 105);
			g.drawLine(85, 120, 255, 120);
			g.drawString("Center", 100, 140);
			g.drawString("=("+Integer.toString(S.getX())+
					","+Integer.toString(S.getY())+")",
					185, 140);
			g.drawString("Radius", 100, 160);
			g.drawString("="+Integer.toString(S.getRadius()),
					185, 160);
			g.drawString("Surface", 100, 180);
			g.drawString("="+Double.toString(roundDigits(S.getSerface(),2)),
					185, 180);
			g.drawString("Volume", 100, 200);
			g.drawString("="+Double.toString(roundDigits(S.getVolume(),1)),
					185, 200);
			g.drawRect(75, 75, 190, 150);
			// Draw Shape
			g.drawOval(S.getX(), S.getY()+S.getRadius()-25, S.getRadius()*2, S.getRadius()/2);
			g.drawLine(S.getX(), S.getY()+S.getRadius(), S.getX()+S.getRadius(), S.getY()+S.getRadius());
			g.drawOval(S.getX(), S.getY(), S.getRadius()*2, S.getRadius()*2);
			// Draw Labels
			g.drawString("("+Integer.toString(S.getX())+","+Integer.toString(S.getY())+")",
					S.getX()+S.getRadius()-20, S.getY()+S.getRadius()+10);
			g.drawString(Integer.toString(S.getRadius()), (S.getX()+S.getX()+S.getRadius())/2,  S.getY()+S.getRadius()-10);
	 }
	 case "Cone":
	 {
		// Draw variable display box
			g.drawString("Cone Properties", 110, 105);
			g.drawLine(85, 120, 255, 120);
			g.drawString("Center", 100, 140);
			g.drawString("=("+Integer.toString(Co.getX())+
					","+Integer.toString(Co.getY())+")",
					185, 140);
			g.drawString("Radius", 100, 160);
			g.drawString("="+Integer.toString(Co.getRadius()),
					185, 160);
			g.drawString("Height", 100, 180);
			g.drawString("="+Integer.toString(Co.getHeight()),
					185, 180);
			g.drawString("Surface", 100, 200);
			g.drawString("="+Double.toString(roundDigits(Co.getSurface(),2)),
					185, 200);
			g.drawString("Volume", 100, 220);
			g.drawString("="+Double.toString(roundDigits(Co.getVolume(),1)),
					185, 220);
			g.drawRect(75, 75, 190, 150);
			// Draw Shape
			g.drawOval(Co.getX(), Co.getY(), Co.getRadius()*2, Co.getRadius()/4);
			g.drawLine(Co.getX()+Co.getRadius(), Co.getY()+Co.getRadius()/8,Co.getX()+(Co.getRadius()*2),
					Co.getY()+Co.getRadius()/8 );
			g.drawLine(Co.getX()+Co.getRadius(), Co.getY()+Co.getRadius()/8, 
					Co.getX()+Co.getRadius(), (Co.getY()+Co.getRadius()/8)-Co.getHeight());
			g.drawLine(Co.getX()+Co.getRadius(), (Co.getY()+Co.getRadius()/8)-Co.getHeight(),
					Co.getX(),Co.getY()+Co.getRadius()/8);
			g.drawLine(Co.getX()+Co.getRadius(), (Co.getY()+Co.getRadius()/8)-Co.getHeight(),
					Co.getX()+(Co.getRadius()*2),Co.getY()+Co.getRadius()/8 );
			// Add Labels
			g.drawString(Integer.toString(Co.getRadius()), ((Co.getX()+Co.getRadius()+Co.getX()+Co.getRadius()*2)/2)-20, 
					(Co.getY()+Co.getRadius()/8)-5);
			g.drawString(Integer.toString(Co.getHeight()), Co.getX()+Co.getRadius()+5,
					((Co.getY()+Co.getRadius()/8)+((Co.getY()+Co.getRadius()/8)-Co.getHeight()))/2);
	}
	 
	 case "Cylinder":
	 {
		// Draw variable display box
			g.drawString("Cylinder Properties", 110, 105);
			g.drawLine(85, 120, 255, 120);
			g.drawString("Center", 100, 140);
			g.drawString("=("+Integer.toString(y.getX())+
					","+Integer.toString(y.getY())+")",
					185, 140);
			g.drawString("Radius", 100, 160);
			g.drawString("="+Integer.toString(y.getRadius()),
					185, 160);
			g.drawString("Height", 100, 180);
			g.drawString("="+Integer.toString(y.getHeight()),
					185, 180);
			g.drawString("Surface", 100, 200);
			g.drawString("="+Double.toString(roundDigits(y.getSurface(),2)),
					185, 200);
			g.drawString("Volume", 100, 220);
			g.drawString("="+Double.toString(roundDigits(y.getVolume(),2)),
					185, 220);
			g.drawRect(75, 75, 190, 150);
			// Draw Shape
			g.drawOval(y.getX(), y.getY(), y.getRadius()*2, y.getRadius()/4);
			g.drawLine(y.getX()+y.getRadius(), y.getY()+y.getRadius()/8,
					y.getX()+y.getRadius(), (y.getY()+y.getRadius()/8)+y.getHeight());
			g.drawOval(y.getX(), y.getY()+y.getHeight(),
					y.getRadius()*2, y.getRadius()/4);
			g.drawLine(y.getX()+y.getRadius(), (y.getY()+y.getRadius()/8)+y.getHeight(),
					y.getX()+(y.getRadius()*2), (y.getY()+y.getRadius()/8)+y.getHeight());
			g.drawLine(y.getX(), y.getY()+y.getRadius()/8, y.getX(),
					(y.getY()+y.getRadius()/8)+y.getHeight());
			g.drawLine(y.getX()+(y.getRadius()*2), y.getY()+y.getRadius()/8, 
					y.getX()+(y.getRadius()*2),(y.getY()+y.getRadius()/8)+y.getHeight());
			//Add Labels
			g.drawString(Integer.toString(y.getRadius()), (((y.getX()+y.getRadius())+y.getX()+(y.getRadius()*2))/2)-10, 
					((y.getY()+y.getRadius()/8)+y.getHeight())-5);
			g.drawString(Integer.toString(y.getHeight()), y.getX()+y.getRadius()+5,
					((y.getY()+y.getRadius()/8)+(y.getY()+y.getRadius()/8)+y.getHeight())/2);
			
	 }
}	 
	 
}
	public static double roundDigits(double x, int d) {
			return (Math.round(x*Math.pow(10, d))/Math.pow(10, d));
	}
}
