import javax.swing.JOptionPane;

public class Rectangle {
	
	// Data members (primary attributes)
	private int xTopleft;
	private int yTopleft;
	private int width;
	private int height;
	
	// Constructors
	public Rectangle()   //no-argument constructor
	{
		xTopleft= 0;
		yTopleft =0;
		width= 0;
		height=0;
	}
	public Rectangle(int x, int y, int w, int h )  //arg constructor
	{
		xTopleft= 0;
		yTopleft =0;
		width= 0;
		height=0;
	}
// accesors
	public int getxTopLeft() {return xTopleft;}
	public int getyTopLeft() {return yTopleft;}
	public int getWidth() {return width;}
	public int getHeight() {return height;}
	
	// other methods calculate secondary attributes
	public int getPerimeter() {return 2* (width+height);}
	public int getArea() {return width * height;}
	public void getAttributes()
	{
		String input;
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"XTopLeft Corner of Rectangle", JOptionPane.INFORMATION_MESSAGE);
		xTopleft = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"YTopLeft Corner of Rectangle", JOptionPane.INFORMATION_MESSAGE);
		yTopleft = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Height of Rectangle", JOptionPane.INFORMATION_MESSAGE);
		height = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Width of Rectangle", JOptionPane.INFORMATION_MESSAGE);
		width = Integer.parseInt(input);
	}
	
}
