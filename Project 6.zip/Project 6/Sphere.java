import javax.swing.JOptionPane;

public class Sphere {
	//Data Members
	private int X;
	private int Y;
	private int r;
	
	//No Argument Constructor
	public Sphere() {
		int x =0;
		int y =0;
		int radius =0;
	}
	//Argument Constructor
	public Sphere(int radius, int x, int y){
		int X =x;
		int Y =y;
		int r =radius;
	}
	
	//Accesors
	public int getRadius(){return r;}
	public int getX(){return X;}
	public int getY(){return Y;}
	
	//Calculate volume    V= 4/3*PI*radius cubed
	public double getVolume() {return (4.0/3.0)*Math.PI*r*r*r;}
	//Calculate SUrafce  SA =4*pi*radius squared
	public double getSerface() {return 4*Math.PI*(r*r);}
	
	//Get Attributes
	public void getAttributes() {
		String input;
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"X Center of Sphere", JOptionPane.INFORMATION_MESSAGE);
		X = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Y Center of Sphere", JOptionPane.INFORMATION_MESSAGE);
		Y = Integer.parseInt(input);
		
		input= JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Radius of Sphere", JOptionPane.INFORMATION_MESSAGE);
		r = Integer.parseInt(input);
	}
}
