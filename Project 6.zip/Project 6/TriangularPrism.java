import javax.swing.JOptionPane;

public class TriangularPrism {

		//Data members
		private int x1;
		private int y1;
		private int x2;
		private int y2;
		private int x3;
		private int y3;
		private int Height;
	
		
		//Constructors
		public TriangularPrism()   //no-argument constructor
		{
			 int x1 =0;
			 int y1=0;
			 int x2=0;
			 int y2=0;
			 int x3=0;
			 int y3=0;
			 int Height=0;
		}
		public TriangularPrism(int x, int y, int w, int z, int a, int b, int h )  //constructor
		{
			 int x1 =x;
			 int y1=y;
			 int x2=w;
			 int y2=z;
			 int x3=a;
			 int y3=b;
			 int Height=h;
		}
		//accesors
		public int getX1(){return x1;}
		public int getY1(){return y1;}
		public int getX2(){return x2;}
		public int getY2(){return y2;}
		public int getX3(){return x3;}
		public int getY3(){return y3;}
		public int getHeight(){return Height;}
		// calculating each side of triangular surface with same calculations of traingle class
		public double getSide1() {
			double point1 =(x1-x2)*(x1-x2);
			double point2= (y1-y2)*(y1-y2);
			double side= Math.sqrt(point1 + point2);
			return side;
		}
		public double getSide2(){
			double point1 =(x1-x3)*(x1-x3);
			double point2= (y1-y3)*(y1-y3);
			double side2= Math.sqrt(point1 + point2);
			return side2;
		}
		public double getSide3(){
			double point1 =(x2-x3)*(x2-x3);
			double point2= (y2-y3)*(y2-y3);
			double side3= Math.sqrt(point1 + point2);
			return side3;
		}
		public double getBaseArea() {
			double side1 = getSide1();
			double side2 = getSide2();
			double side3 = getSide3();
			double S = (side1+side2+side3)/2;
			return Math.sqrt(S*(S-side1)*(S-side2)*(S-side3));
		}
		public double getSurface()   //SA = ph + 2B <-- formula for surface area
		{						     //P is perimeter of base, b is area of base, h is height
		  double x= getSide1();      
		  double y= getSide2();
		  double z= getSide3();
		  double p =x+y+z;
		  double b = getBaseArea();
		  return  p*getHeight()+(2*b);		  
		}
		public double getVolume()    // V = (Ba)(H)
		{
			  int h = getHeight();
			  double b = getBaseArea();
			  return(b*h);
		}
		public void getAttributes() {
			String input;
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"X1 Corner of Base Triangle", JOptionPane.INFORMATION_MESSAGE);
			x1 = Integer.parseInt(input);
			
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"Y1 Corner of Base Triangle", JOptionPane.INFORMATION_MESSAGE);
			y1 = Integer.parseInt(input);
			
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"X2 Corner of Base Triangle", JOptionPane.INFORMATION_MESSAGE);
			x2 = Integer.parseInt(input);
			
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"Y2 Corner of Base Triangle", JOptionPane.INFORMATION_MESSAGE);
			y2 = Integer.parseInt(input);
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"X3 Corner of Base Triangle", JOptionPane.INFORMATION_MESSAGE);
			x3 = Integer.parseInt(input);
			
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"Y3 Corner of Base Triangle", JOptionPane.INFORMATION_MESSAGE);
			y3 = Integer.parseInt(input);
			input= JOptionPane.showInputDialog(null,
					"Please Enter a Positive Integer",
					"Height of TriangularPrism", JOptionPane.INFORMATION_MESSAGE);
			Height = Integer.parseInt(input);
			
		}

}
