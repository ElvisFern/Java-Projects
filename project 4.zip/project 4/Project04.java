import javax.swing.JOptionPane;

public class Project04 {
	
	public static void main(String[] args)
	{
		menu();
		
	}
// input menu and where calculations an display methods are called
	public static void menu()
	{
		String input;
		int option =0;
		while(option!= 5)
		{
		input = JOptionPane.showInputDialog(null,
				"1. (1 + 2 + 3 +  ........+N)"+"\n"+
				"2. (1 + 8 + 27 + ........+N^3)"+"\n"+
				"3. (1/3 + 2/5 +  ........+N/(2N+1)"+"\n"+
				"4. (1/2 + 2/4 +  ........+N/2N!"+"\n"+
				"\n"+
				"5.EXIT"+"\n",
				"Math Series",JOptionPane.INFORMATION_MESSAGE
				);
		option= Integer.parseInt(input);
		//Calculation and displays bsed on option selected from the menu
		switch(option)
		{
		case 1:
		{
			 input = JOptionPane.showInputDialog(null,
					"Please ENter a positve Integer Number",
					"Enter N",JOptionPane.INFORMATION_MESSAGE
					);
			 int n = Integer.parseInt(input);
			 double result = mathSeries1(n);
			 System.out.println("n="+n+"result ="+result);
			 displayResult(option,n,result);
			
			break;
		}
		case 2:
		{
			input = JOptionPane.showInputDialog(null,
					"Please Enter a positve Integer Number",
					"Enter N",JOptionPane.INFORMATION_MESSAGE
					);
			 int n = Integer.parseInt(input);
			 double result = mathSeries2(n);
			 System.out.println("n="+n+"result ="+result);
			 displayResult(option,n,result);
				
				break;
		}
		case 3:{
			input = JOptionPane.showInputDialog(null,
					"Please Enter a positve Integer Number",
					"Enter N",JOptionPane.INFORMATION_MESSAGE
					);
			 int n = Integer.parseInt(input);
			 double result = mathSeries3(n);
			 System.out.println("n="+n+"result ="+result);
			 displayResult(option,n,result);
			 break;
		}
		
		case 4:{
			input = JOptionPane.showInputDialog(null,
					"Please Enter a positve Integer Number",
					"Enter N",JOptionPane.INFORMATION_MESSAGE
					);
			 int n = Integer.parseInt(input);
			 double result = mathSeries4(n);
			 System.out.println("n="+n+"result ="+result);
			 displayResult(option,n,result);
		}
		case 5:
		{
			JOptionPane.showMessageDialog(null,
					"Thank You for Using The Math Series",
					"Good Bye",JOptionPane.INFORMATION_MESSAGE
					);
			System.exit(0);
			break;
			}
		default:
			JOptionPane.showMessageDialog(null, 
					"Incorrect Input Value, Please Enter a Number Between 1 and 5",
					"ERROR",JOptionPane.ERROR_MESSAGE);
		}//end of switch
	   }//end of while
		
	}
	// Calculations
	public static double mathSeries1(int n)
	{
		double sum = 0;
		for (int num=1; num <= n;num++ )
		{
			sum = sum + num;
		}
		return sum;
	}
	public static double mathSeries2(int n)
	{
		double sum = 0;
		for (int num=1; num <= n;num++ )
		{
			sum +=  num * num * num; 
			
		}
		return sum;
	}
	public static double mathSeries3(int n)
	{   double x = 0;
		double sum = 0;
		for (int num=1; num <= n;num++ )
		{
			x = (2*num)+1;
			sum =+ num/x;
			
		}
		return sum;
	}
	public static double mathSeries4(int n)
	{	
		double sum = 0;
		double factor = 1;
		for (int num=1; num <= n;num++ )
		{	double x =0;
			factor *= 2*num;
			x = num/factor;
			sum =+ x; 
		}
		return sum;
	}	
	//display method
	public static void displayResult(int option, int n, double result)
	{
		switch(option)
		{
			case 1:
			{
				JOptionPane.showMessageDialog(null,
				"            CSC 229 - Project 4 (Math Series)"+"\n"+
				"_____________________________________________"+"\n"+
				"1 + 2 + 3 .....+"+n+"= "+result,
				"Math Series",JOptionPane.INFORMATION_MESSAGE
				);
				break;
			}
			case 2:
			{
				JOptionPane.showMessageDialog(null,
						"            CSC 229 - Project 4 (Math Series)"+"\n"+
						"_____________________________________________"+"\n"+
						"1 + 8 + 37 .....+"+n+"= "+ result,
						"Math Series",JOptionPane.INFORMATION_MESSAGE);
			
				break;	
			}
			case 3:{
				JOptionPane.showMessageDialog(null,
						"            CSC 229 - Project 4 (Math Series)"+"\n"+
						"_____________________________________________"+"\n"+
						"1/3 + 2/5 .....+"+n+"= "+result,
						"Math Series",JOptionPane.INFORMATION_MESSAGE);
				
				break;
			}
			
			case 4:{
				JOptionPane.showMessageDialog(null,
						"            CSC 229 - Project 4 (Math Series)"+"\n"+
						"_____________________________________________"+"\n"+
						"1/2 + 2/4 .....+"+n+"= "+result,
						"Math Series",JOptionPane.INFORMATION_MESSAGE);
				break;
			}
				
				
				
				
	  }
	}
	//round method
	public static double roundDigits(double s, int k)
	{
		// s = 156.75423
		// s = s*Math.pow(10,k) (long)156754.23 = 156754/1000.0 =156.754
		s = ((long)s*Math.pow(10, k))/Math.pow(10, k);
		return s;
	}
}



