import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JOptionPane;


public class Project07 extends Frame implements ActionListener
{
		
	String command = "";
	int key;
	int n;
	int min2D, max2D;
	double  Avg, SD;
	boolean found;
	Font f = new Font("SansSerif",Font.BOLD,12);
	Font f1 = new Font("SansSerif",Font.BOLD,16);
	Font f2 = new Font("SanSerif",Font.BOLD,30);
	
	TwoDArray originalArray;
	TwoDArray secondArray;
	TwoDArray result ;
	public static void main(String[] args)
	{
		Frame frame = new Project07();	
		frame.setResizable(true);
		frame.setSize(1000,800);
		frame.setVisible(true);
	}
	
	public Project07()
	{
		setTitle("CSC 229 - Project 7 - 2D Arrays");
		
		// Create Menu
		   			
		MenuBar mb = new MenuBar();
		setMenuBar(mb);
		
		Menu fileMenu = new Menu("File");
		mb.add(fileMenu);
		
		MenuItem miAbout = new MenuItem("About");
		miAbout.addActionListener(this);
		fileMenu.add(miAbout);
		
		MenuItem miExit = new MenuItem("Exit");
		miExit.addActionListener(this);
		fileMenu.add(miExit);
		
		Menu actionMenu = new Menu("Two Dimensional Array");
		mb.add(actionMenu);
		
		MenuItem miCreate2D = new MenuItem("Create Array");
		miCreate2D.addActionListener(this);
		actionMenu.add(miCreate2D);
		
		//stats menu
		Menu statsMenu1D = new Menu("Statistics");
		actionMenu.add(statsMenu1D);
		
		MenuItem miMinimum = new MenuItem("Array Minimum");
		miMinimum.addActionListener(this);
		statsMenu1D.add(miMinimum);
		
		MenuItem miMaximum = new MenuItem("Array Maximum");
		miMaximum.addActionListener(this);
		statsMenu1D.add(miMaximum);
		
		MenuItem miAverage = new MenuItem("Array Average");
		miAverage.addActionListener(this);
		statsMenu1D.add(miAverage);
		
		MenuItem miArrayStandardDeviation = new MenuItem("Array Standard Deviation");
		miArrayStandardDeviation.addActionListener(this);
		statsMenu1D.add(miArrayStandardDeviation);
		
		MenuItem miSearchArray = new MenuItem("Search Array");
		miSearchArray.addActionListener(this);
		actionMenu.add(miSearchArray);
		
		// array operations
		Menu opsMenu = new Menu("Operations");
		
		actionMenu.add(opsMenu);
		
		MenuItem miAdd = new MenuItem("Add");
		miAdd.addActionListener(this);
		opsMenu.add(miAdd);
		
		MenuItem miSubtract = new MenuItem("Subtract");
		miSubtract.addActionListener(this);
		opsMenu.add(miSubtract);
		
		MenuItem miMultiply = new MenuItem("Multiply");
		miMultiply.addActionListener(this);
		opsMenu.add(miMultiply);
		
		// End program when window is closed
		
		WindowListener l = new WindowAdapter()
		{
						
			public void windowClosing(WindowEvent ev)
			{
				System.exit(0);
			}
			
			public void windowActivated(WindowEvent ev)
			{
				repaint();
			}
			
			public void windowStateChanged(WindowEvent ev)
			{
				repaint();
			}
		
		};
		
		ComponentListener k = new ComponentAdapter()
		{
			public void componentResized(ComponentEvent e) 
			{
        		repaint();           
    		}
		};
		
		// register listeners
			
		this.addWindowListener(l);
		this.addComponentListener(k);

	}
	
//******************************************************************************
//  called by windows manager whenever the application window performs an action
//  (select a menu item, close, resize, ....
//******************************************************************************

	public void actionPerformed (ActionEvent ev)
		{
			// figure out which command was issued
			
			command = ev.getActionCommand();
			
			// take action accordingly
		switch(command)
		{
			case "About":
			{
				repaint();
				break;
			}
			case "Exit":
			{
				System.exit(0);
			}
			case "Create Array":
			{
				originalArray = new TwoDArray();
				originalArray.createArray();
				secondArray = null;
				result = null;
				repaint();
				break;
			}
			case "Array Minimum":
				{	
					min2D =originalArray.getMinimum();
					repaint();
					break;
				}
			case "Array Maximum":
			{	
				max2D =originalArray.getMaximum();
				repaint();
				break;
			}
			case "Array Average":
			{	
				Avg =originalArray.getAverage();
				repaint();
				break;
			}
			
			case "Array Standard Deviation":
			{	
				SD =originalArray.getStandardDeviation();
				repaint();
				break;
			}
			
			case "Search Array":
			{	
				String input;
				input = JOptionPane.showInputDialog(null,"Please enter an integer number to search for:",
						"Search for Value in the Array",JOptionPane.QUESTION_MESSAGE);
			    key = Integer.parseInt(input);
				found =originalArray.search(key);
				repaint();
				break;
			}
			
			case "Add":
			{
				if (originalArray == null)
				{
					originalArray = new TwoDArray();
					originalArray.createArray();
				}
				if(secondArray == null)
				{
					secondArray = new TwoDArray();
					secondArray.createArray();
				}
				boolean comp = false;
				while (!comp)
				{
					switch(command)
					{
					case "Add":
					{
						if(originalArray.getArray().length != secondArray.getArray().length ||
								originalArray.getArray()[0].length != secondArray.getArray()[0].length)
							
						{
							JOptionPane.showMessageDialog(null, 
									"Please Create a 2d Array with " + 
									originalArray.getArray().length+" Rows and "+
									originalArray.getArray()[0].length + " Columns",
									"Incompatible Dimentions", JOptionPane.ERROR_MESSAGE
									);
							secondArray= new TwoDArray();
							secondArray.createArray();
						}
						
						comp = true;
						break;
					}
					
					
					}
				}
				if(command.equals("Add"))
					result = originalArray.add(secondArray);
				
				
				repaint();
				break;
			}
			case "Subtract":
			{
				if (originalArray == null)
				{
					originalArray = new TwoDArray();
					originalArray.createArray();
				}
				if(secondArray == null)
				{
					secondArray = new TwoDArray();
					secondArray.createArray();
				}
				boolean comp = false;
				while (!comp)
				{
					switch(command)
					{
					case "Subtract":
					{
						if(originalArray.getArray().length != secondArray.getArray().length ||
								originalArray.getArray()[0].length != secondArray.getArray()[0].length)
							
						{
							JOptionPane.showMessageDialog(null, 
									"Please Create a 2d Array with " + 
									originalArray.getArray().length+" Rows and "+
									originalArray.getArray()[0].length + " Columns",
									"Incompatible Dimentions", JOptionPane.ERROR_MESSAGE
									);
							secondArray= new TwoDArray();
							secondArray.createArray();
						}
						
						comp = true;
						break;
					}
					
					
					}
				}
				if(command.equals("Subtract"))
					result = originalArray.Subtract(secondArray);
				
				
				repaint();
				break;
			}
					
			
			case "Multiply":
			{
				if (originalArray == null)
				{
					originalArray = new TwoDArray();
					originalArray.createArray();
				}
				if(secondArray == null)
				{
					secondArray = new TwoDArray();
					secondArray.createArray();
				}
				boolean comp = false;
				while (!comp)
				{
					switch(command)
					{
					case "Multiply":
					{
						if(originalArray.getArray().length != secondArray.getArray().length ||
								originalArray.getArray()[0].length != secondArray.getArray()[0].length)
							
						{
							JOptionPane.showMessageDialog(null, 
									"Please Create a 2d Array with " + 
									originalArray.getArray().length+" Rows and "+
									originalArray.getArray()[0].length + " Columns",
									"Incompatible Dimentions", JOptionPane.ERROR_MESSAGE
									);
							secondArray= new TwoDArray();
							secondArray.createArray();
						}
						
						comp = true;
						break;
					}
					
					
					}
				}
				if(command.equals("Multiply"))
					result = originalArray.Multiply(secondArray);
				
				
				repaint();
				break;
			}
		}// switch
	
	}
//********************************************************
// called by repaint() to redraw the screen
//********************************************************
		
		public void paint(Graphics g)
		{
			// Check Command issued, take action accordingly
			int ww = this.getWidth();
			
			g.setFont(f);
		switch(command)
		{
		case "About":
		{
			g.drawString("2D Arrays",400,100);
			g.drawLine(350,120, 550, 120);
			g.drawString(" This program creates  two dimensional arrays and performs the desired action to the arrays created",200,140);
			g.drawString(" get the array Maximum, minimum, average, add a seocnd array, Standrad deviation of 2 arrays,subtract and multiply ", 200, 160);
		}
			case "Create Array":
			{
				int y = 100;
				int[][] t = originalArray.getArray();
				int x = (ww - 35*t[0].length)/2;
				int currentY = displayArray(g,t,x,y,ww,"Original Array");
				drawGrid(g,x, y, t.length, t[0].length);
				break;
			}
			
			case "Array Minimum":
			{
				int y = 100;
				int[][] t = originalArray.getArray();
				int x = (ww - 35*t[0].length)/2;
				int currentY = displayArray(g,t,x,y,ww,"Original Array");
				drawGrid(g,x, y, t.length, t[0].length);
				g.setColor(Color.RED);
				g.setFont(f1);
				g.drawString("Minimum ="+" " +min2D, ww/2-60, currentY+25);
				break;
			}
			case "Array Maximum":
			{
				int y = 100;
				int[][] t = originalArray.getArray();
				int x = (ww - 35*t[0].length)/2;
				int currentY = displayArray(g,t,x,y,ww,"Original Array");
				drawGrid(g,x, y, t.length, t[0].length);
				g.setColor(Color.RED);
				g.setFont(f1);
				g.drawString("Maximum ="+" " +max2D, ww/2-60, currentY+25);
				break;
			}
			case "Array Average":
			{
				int y = 100;
				int[][] t = originalArray.getArray();
				int x = (ww - 35*t[0].length)/2;
				int currentY = displayArray(g,t,x,y,ww,"Original Array");
				drawGrid(g,x, y, t.length, t[0].length);
				g.setColor(Color.RED);
				g.setFont(f1);
				g.drawString("Average ="+" " +Avg, ww/2-60, currentY+25);
				break;
			}
			case "Array Standard Deviation":
			{
				int y = 100;
				int[][] t = originalArray.getArray();
				int x = (ww - 35*t[0].length)/2;
				int currentY = displayArray(g,t,x,y,ww,"Original Array");
				drawGrid(g,x, y, t.length, t[0].length);
				g.setColor(Color.RED);
				g.setFont(f1);
				g.drawString("Standard Deviation ="+" " +SD, ww/2-105, currentY+25);
				break;
			}
			
				
					
			
			case "Search Array":
			{
				int y = 100;
				int[][] t = originalArray.getArray();
				int x = (ww - 35*t[0].length)/2;
				int currentY = displayArray(g,t,x,y,ww,"Original Array");
				drawGrid(g,x, y, t.length, t[0].length);
				g.setColor(Color.RED);
				g.setFont(f1);
				String result = "";
				if (found) result = "Found";
				else       result = "NOT Found";
				g.drawString("Search Key  **** "+Integer.toString(key)+" ****  " +result, ww/2-130, currentY+25);
				break;
			}
			case "Add":
			{
				int y = 100;
				int[][] t = originalArray.getArray();
				int [][] e = secondArray.getArray();
				int [][] q = result.getArray();
				int x = (ww - 35*t[0].length)/2;
				int currentY = displayArray(g,t,x-300,y,ww,"");
				drawGrid(g,x-300, y, t.length, t[0].length);
				displayArray( g,  x-150,  y-20, "A");
				
				int currentX = displayArray(g,e,x+300,y,ww,"");
				drawGrid(g,x+300, y, t.length, t[0].length);
				displayArray( g,  x+450,  y-20, "B");
				
				int currentZ = displayArray(g,q,x,y+300,ww,"");
				drawGrid(g,x, y+300, q.length, q[0].length);
				displayArray( g,  x+150,  y+280, "C");
				displayArray( g,  x+150,  y+150, "+");
				break;
			}
			case "Subtract":
			{
				int y = 100;
				int[][] t = originalArray.getArray();
				int [][] e = secondArray.getArray();
				int [][] q = result.getArray();
				int x = (ww - 35*t[0].length)/2;
				int currentY = displayArray(g,t,x-300,y,ww,"");
				drawGrid(g,x-300, y, t.length, t[0].length);
				displayArray( g,  x-150,  y-20, "A");
				
				int currentX = displayArray(g,e,x+300,y,ww,"");
				drawGrid(g,x+300, y, t.length, t[0].length);
				displayArray( g,  x+450,  y-20, "B");
				
				int currentZ = displayArray(g,q,x,y+300,ww,"");
				drawGrid(g,x, y+300, q.length, q[0].length);
				displayArray( g,  x+150,  y+280, "C");
				displayArray( g,  x+150,  y+150, "-");
				break;

			}
			case "Multiply":
			{
				int y = 100;
				int[][] t = originalArray.getArray();
				int [][] e = secondArray.getArray();
				int [][] q = result.getArray();
				int x = (ww - 35*t[0].length)/2;
				int currentY = displayArray(g,t,x-300,y,ww,"");
				drawGrid(g,x-300, y, t.length, t[0].length);
				displayArray( g,  x-150,  y-20, "A");
				
				int currentX = displayArray(g,e,x+300,y,ww,"");
				drawGrid(g,x+300, y, t.length, t[0].length);
				displayArray( g,  x+450,  y-20, "B");
				
				int currentZ = displayArray(g,q,x,y+300,ww,"");
				drawGrid(g,x, y+300, q.length, q[0].length);
				displayArray( g,  x+150,  y+280, "C");
				displayArray( g,  x+150,  y+150, "*");
				break;
				
			}
	
		}
			
		}
		public int displayArray(Graphics g, int[][] a, int x, int y, int ww, String title)
		{
			g.setFont(f1);
			g.setColor(Color.RED);
			g.drawString(title, (ww-10*title.length())/2, 75);
			
			g.setFont(f);
			g.setColor(Color.BLACK);
			int xs = x;
			int ys = y;
			
			for (int row = 0; row < a.length; row++) 
			{
				for (int column = 0; column < a[0].length; column++) 
				{
					g.drawString(Integer.toString(a[row][column]), xs, ys);
					xs = xs + 35;
				}
				xs = x;
				ys = ys + 20;
			}
			// draw grid
			return ys;
			
		}
		public void displayArray(Graphics g,  int x, int y, String title)
		{
			g.setFont(f1);
			g.setColor(Color.RED);
			g.drawString(title, x, y);
			
		}
			
	
		public void drawGrid(Graphics g,int x, int y, int r, int c)
		{
			// draw horizontal lines
			int ys = y-15;
			int xs =x-10;
			int xe = x-10;
			int ye = y-15;
			for (int row = 0; row < r+1; row++) 
			{
				for (int column = 0; column < c; column++) 
				{
					g.drawLine(xs,ys, xe+35, ye);
					xe = xe + 35;
				}
				xe = xs;
				ye = ye + 20;
				ys = ys+ 20;
			}
			
			// draw vertical lines
			 xs = x-10;
			 ys = y-15;
			 xe =x-10;
			 ye =y-15;
			for (int row = 0; row < c+1; row++) 
			{
				for (int column = 0; column < r; column++) 
				{
					g.drawLine(xs,ys, xe, ye+20);
					ye = ye + 20;
				}
				xs = xs +35;
				xe =xs;
				ye = ys;
			}
		}
	}
