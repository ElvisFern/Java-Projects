import javax.swing.JOptionPane;

public class TwoDArray 
{
	private int[][] array;
	private int low;
	private int high;
	
public TwoDArray(int r, int c, int l, int h)
{
	array = new int[r][c];
	for (int i=0; i<r; i++)
		for (int j=0; j<c; j++)
    	array[i][j] = l + (int)((h-l+1)*Math.random());
}
public TwoDArray()
{
	low = 1;
	high = 100;
	array = new int[10][10];
	for (int i=0; i<10; i++)
		for (int j=0; j<10; j++)
    	array[i][j] = low + (int)((high-low+1)*Math.random());
}
public int[][] getArray() { return array;}
public int getLow() { return low;}
public int getHigh() { return high;}
public void createArray()
{
	String input = JOptionPane.showInputDialog(null,"Please enter an integer < 50:",
			"# Rows of Two-Dimensional Array",JOptionPane.QUESTION_MESSAGE);
    int r =Integer.parseInt(input);
    
    input = JOptionPane.showInputDialog(null,"Please enter an integer < 50:",
			"# Colums of Two-Dimensional Array",JOptionPane.QUESTION_MESSAGE);
    int c =Integer.parseInt(input);
    
    array = new int[r][c];
    input = JOptionPane.showInputDialog(null,"Please enter an integer > 0:",
			"Lowest Value in the Array",JOptionPane.QUESTION_MESSAGE);
    low = Integer.parseInt(input);
    input = JOptionPane.showInputDialog(null,"Please enter an integer < 1000:",
			"Highest Value in the Array",JOptionPane.QUESTION_MESSAGE);
    high = Integer.parseInt(input);
    for (int i=0; i<array.length; i++)
    	for (int j=0; j<array[i].length; j++)
    	array[i][j] = low + (int)((high-low+1)*Math.random());
}
public int getMinimum()
{
int min = Integer.MAX_VALUE;
	
	for (int i = 0; i < array.length; i++) 
	{
		for (int j = 0; j < array[0].length; j++) 
		{
			if(array[i][j] < min)
				min = array[i][j];
		}
	}
	return min;
}

public int getMaximum()
{
int max = Integer.MIN_VALUE;
	
	for (int i = 0; i < array.length; i++) 
	{
		for (int j = 0; j < array[0].length; j++) 
		{
			if(array[i][j] > max)
				max = array[i][j];
		}
	}
	return max;
}

public double getAverage() 
{
	int sum =0;
	double count =0.0;
	for (int i = 0; i < array.length; i++) 
	{
		for (int j = 0; j < array[0].length; j++) 
		{
			sum = array[i][j] + sum;
			count++;
		}
	}
	return Math.round(sum/count);
}

public double getStandardDeviation() 
{
	int sum =0;
	double avg =0.0;
	int count =0;
	double s =0.0;
	double sDeviation =0.0;
	for (int i = 0; i < array.length; i++) 
	{
		for (int j = 0; j < array[0].length; j++) 
		{
			sum = array[i][j] + sum;
			count++;
		}
	}
	avg = sum/count;
	for (int i = 0; i < array.length; i++) 
	{
		for (int j = 0; j < array[0].length; j++) 
		{
			s = s+ Math.pow(array[i][j] - avg, 2);
			
		}
	}
	sDeviation = Math.sqrt((s/count));
	return Math.round(sDeviation);
}
public boolean search(int key)
{
	boolean x = false;
	for(int i=0;i<array.length;i++) 
	{
		for(int j=0;j<array[0].length;j++) 
		{
			if(key==array[i][j]) {x= true;}
			
		}
	}
	return x;
}
public TwoDArray add(TwoDArray x)
{
	TwoDArray r = null;
	int[][] a = this.getArray();
	int[][] b = x.getArray();
	int[][] c = new int[a.length][a[0].length] ;
	
	for (int i = 0; i < array.length; i++) 
	{
		for (int j = 0; j < array[0].length; j++) 
		{
			c[i][j] = a[i][j] + b[i][j];
		}
	}
	r = new TwoDArray();
	r.array = c;
	r.low = r.getMinimum();
	r.high = r.getMaximum();
	
	return r;
	
}

public TwoDArray Subtract(TwoDArray x)
{
	TwoDArray r = null;
	int[][] a = this.getArray();
	int[][] b = x.getArray();
	int[][] c = new int[a.length][a[0].length] ;
	
	for (int i = 0; i < array.length; i++) 
	{
		for (int j = 0; j < array[0].length; j++) 
		{
			c[i][j] = a[i][j] - b[i][j];
		}
	}
	r = new TwoDArray();
	r.array = c;
	r.low = r.getMinimum();
	r.high = r.getMaximum();
	
	return r;
	
}
public TwoDArray Multiply(TwoDArray x)
{
	TwoDArray r = null;
	int[][] a = this.getArray();
	int[][] b = x.getArray();
	int[][] c = new int[a.length][a[0].length] ;
	
	for (int i = 0; i < array.length; i++) 
	{
		for (int j = 0; j < array[0].length; j++) 
		{
			c[i][j] = a[i][j] * b[i][j];
		}
	}
	r = new TwoDArray();
	r.array = c;
	r.low = r.getMinimum();
	r.high = r.getMaximum();
	
	return r;
	
}

}
